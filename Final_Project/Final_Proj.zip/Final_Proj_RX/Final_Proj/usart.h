void usart_init(void);
void usart_send(unsigned char data);
void usart_sends(char *s);
unsigned int usart_receive(void);
